!include(version.md)

###### &copy; 2018 - Gateway Programing School, Inc.

###### [Gateway Programming School, Inc. Open License](http://gatewayprogrammingschool.azurewebsites.net/license)