
### Ranger Apprenticeships

```note
Note:
We need some good text on being a Ranger and how the apprenticeships shape the character.

```