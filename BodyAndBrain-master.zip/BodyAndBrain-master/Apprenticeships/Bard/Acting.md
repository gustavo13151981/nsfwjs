
#### Acting

```note
Note:
Flesh out what the acting apprenticeship means for the character.

```
