
### Bard Apprenticeships

```note
Note:
We need some good text on being a Bard and how the apprenticeships shape the character.

```

!include(Acting.md)

!include(Fencing.md)

!include(Politician.md)
