
#### Fencing

```note
Note:
Flesh out what the fencing apprenticeship means for the character.

```
