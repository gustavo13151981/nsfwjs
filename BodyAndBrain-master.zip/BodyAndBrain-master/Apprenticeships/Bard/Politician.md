
#### Politician

```note
Note:
Flesh out what the politician apprenticeship means for the character.

```
