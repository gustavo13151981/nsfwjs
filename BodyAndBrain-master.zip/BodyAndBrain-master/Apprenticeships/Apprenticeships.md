
## Apprenticeships

_____

```note
Note:
Introduction to Apprenticeships

```

!include(./Bard/Apprenticeships.md)
!include(./Berserker/Apprenticeships.md)
!include(./Cleric/Apprenticeships.md)
!include(./Conjuror/Apprenticeships.md)
!include(./Fighter/Apprenticeships.md)
!include(./Paladin/Apprenticeships.md)
!include(./Ranger/Apprenticeships.md)
!include(./Thief/Apprenticeships.md)
!include(./Wizard/Apprenticeships.md)
