
### Thief Apprenticeships

```note
Note:
We need some good text on being a Thief and how the apprenticeships shape the character.

```