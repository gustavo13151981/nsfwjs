
### Fighter Apprenticeships

```note
Note:
We need some good text on being a Fighter and how the apprenticeships shape the character.

```