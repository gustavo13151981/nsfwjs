
### Paladin Apprenticeships

```note
Note:
We need some good text on being a Paladin and how the apprenticeships shape the character.

```