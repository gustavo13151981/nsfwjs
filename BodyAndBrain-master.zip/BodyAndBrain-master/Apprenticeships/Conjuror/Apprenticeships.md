
### Conjuror Apprenticeships

```note
Note:
We need some good text on being a Conjuror and how the apprenticeships shape the character.

```