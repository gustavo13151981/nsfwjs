
#### Apprenticeship Name (Required)

>TODO:
>Flesh out what the apprenticeship means for the character.

##### Special Ability (Required)

>TODO:
>List one special ability that studying this apprenticeship grants.  Be specific so the Gamemaster and player both understand how to use the ability.

##### Development Package (Required)

>TODO:
>The are the starting skills for the adolescent training (Level 0) for the Apprenticeship.  Upon completion of the Apprenticeship, the character is Level 1 having obtained the listed skills.

###### [Weapons](#Weapon-Skills)

|Primary Melee|Primary Missile|Secondary Melee|Secondary Missile|Tertiary Melee|Tertiary Missile|
|:-----------:|:-------------:|:-------------:|:---------------:|:------------:|:--------------:|
|0						|0							|0							|0								|0						 |0								|

###### [Armor](#Armor-Skills)

|No Armor|Robes|Soft Leather|Rigid Leather|Chain|Plate|Helm|Shield|
|:------:|:---:|:----------:|:-----------:|:---:|:---:|:--:|:----:|
|0			 |0		 |0						|0						|0		|0		|0	 |0			|

###### [Physical Skills](#Physical-Skills)

|Sprint|Run|Swim|Climb|Body General|
|:----:|:-:|:--:|:---:|:----------:|
|0   	 |0	 |0   |0    |0           |

###### [Mental Abilities](#Mental-Abilities)

|Traps|Locks|Persuasion|Item Lore|Read Runes|Use Item|Brain General|
|:---:|:---:|:--------:|:-------:|:--------:|:------:|:-----------:|
|0		|0		|0				 |0				 |0					|0			 |0						 |

###### [Mixed Abilities](#Mixed-Abilities)

|Stealing|Tracking|Hiding|Balancing|Mixed General|
|:------:|:------:|:----:|:-------:|:-----------:|
|0			 |0				|0		 |0				 |0						 |

###### [Arcane Skills](#Arcane-Skills)

|Perception|Body Development|
|:--------:|:--------------:|
|0				 |0								|

###### [Other Skills](#Other-Skills)

|Enchantment|Conjuring|Prayers|Naturalist|Leadership|Songs|Apprenticeship List|
|:---------:|:-------:|:-----:|:--------:|:--------:|:---:|:-----------------:|
|0					|0				|0			|0				 |0					|0		|0									|

##### Skill Stat Changes (Optional)

>TODO:
>List any skills that have their associated stats changed by this apprenticeship.

|Skill|Original Stat(s)|New Stat(s)|
|:----|:---------------|:----------|
|     |                |           |

##### Special Spell List (Optional)

>TODO:
>Describe the spell list, what type of magic it is, it's intended purpose, etc.

|Level|Name|Type|Targets|Range|Area|Modifier|Duration|Description
|:-:|:--|:--|:--|:--|:--|:--|:--|:--
|#|Short name of spell|Directed or Self|Target(s) or Area|How far away the spell effect can be cast|Size of Area Effect in feet|Amount of units affected by the spell such as damage taken or bonus/curse|How long the effects of the spell last.|Description of the spell.  Give enough information to clearly describe functionality and implementation of the spell.
