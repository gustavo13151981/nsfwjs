
### Berserker Apprenticeships

```note
Note:
We need some good text on being a Berserker and how the apprenticeships shape the character.

```

!include(Wrestling.md)
